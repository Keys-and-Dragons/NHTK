from PyQt5 import QtWidgets, QtGui, QtCore
import sys
import psycopg2
from psycopg2 import sql
from generate import PasswordWindow
import datetime

def connect_to_database(db_name, user, password, host="localhost", port="5432"):
    """Подключается к базе данных PostgreSQL."""
    try:
        conn = psycopg2.connect(database=db_name, user=user, password=password, host=host, port=port)
        print("Успешное подключение к базе данных.")
        return conn
    except psycopg2.Error as e:
        print(f"Ошибка подключения к базе данных: {e}")
        return None

def create_table(conn):
    """Создает таблицы в базе данных."""
    try:
        cursor = conn.cursor()

        # Create the records table
        cursor.execute(sql.SQL("""
            CREATE TABLE IF NOT EXISTS all_records (
                id SERIAL PRIMARY KEY,
                service_id INTEGER,
                name VARCHAR(255),
                login VARCHAR(255),
                password VARCHAR(255),
                email VARCHAR(255),
                date_added DATE DEFAULT CURRENT_DATE
            );
        """))
        conn.commit()
        print("Таблица 'all_records' успешно создана или уже существует.")

        # Create the services table
        cursor.execute(sql.SQL("""
            CREATE TABLE IF NOT EXISTS services (
                id SERIAL PRIMARY KEY,
                service_name VARCHAR(255) UNIQUE NOT NULL,
                table_id VARCHAR(255) UNIQUE NOT NULL
            );
        """))
        conn.commit()
        print("Таблица 'services' успешно создана или уже существует.")

        cursor.close()
    except psycopg2.Error as e:
        print(f"Ошибка создания таблицы: {e}")
        conn.rollback()

class LoginWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        # Подключение к базе данных и создание таблицы
        self.conn = connect_to_database('ALL', 'postgres', 'ssn23mzw')
        if self.conn:
            create_table(self.conn)
            self.initialize_services()

    def initialize_services(self):
        """Инициализирует сервисы и записывает их в базу данных."""
        cur = self.conn.cursor()

        # Load existing services from the database
        cur.execute("SELECT service_name, table_id FROM services;")
        existing_services = cur.fetchall()

        for service_name, table_id in existing_services:
            button = QtWidgets.QPushButton(service_name, self)
            button.setStyleSheet(
                "background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: center;"
            )
            button.clicked.connect(self.change_table)
            button.mouseDoubleClickEvent = lambda event, button=button: self.rename_service(button)
            self.service_buttons_layout.addWidget(button)
            setattr(self, f'wind{len(self.service_buttons_layout) - 1}', button)

        cur.close()

    def save_data(self, service_id, data):
        """Сохраняет запись в базу данных."""
        cur = self.conn.cursor()
        try:
            cur.execute(
                """ SELECT * FROM all_records WHERE service_id=%s AND login=%s AND password=%s AND email=%s AND date_added=%s; """,
                (service_id, data['login'], data['password'], data['email'], data['date_added']))
            existing_record = cur.fetchone()
            if existing_record:
                if existing_record[2:] == (data['login'], data['password'], data['email'], data['date_added']):
                    print(f"Record for service_id {service_id} is identical and will not be updated.")
                else:
                    cur.execute(
                        """ UPDATE all_records SET login=%s, password=%s, email=%s, date_added=%s WHERE service_id=%s AND id=%s; """,
                        (data['login'], data['password'], data['email'], data['date_added'], service_id,
                         existing_record[0]))
                    self.conn.commit()
                    print(f"Record for service_id {service_id} updated with new data: {data}")
            else:
                cur.execute(
                    """ INSERT INTO all_records (service_id, name, login, password, email, date_added) VALUES (%s, %s, %s, %s, %s, %s); """,
                    (service_id, data['name'], data['login'], data['password'], data['email'], data['date_added']))
                self.conn.commit()
                print(f"New record saved for service_id {service_id}: {data}")
        except Exception as e:
            print(f"Error while saving data: {e}")
            self.conn.rollback()
        finally:
            cur.close()

    def update_record(self, service_id, row, data):
        """Обновляет запись в базе данных."""
        cur = self.conn.cursor()
        cur.execute("""
            UPDATE all_records SET login=%s, password=%s, email=%s, date_added=%s
            WHERE service_id=%s AND id=%s;
        """, (data['login'], data['password'], data['email'], data['date_added'], service_id, row + 1))
        self.conn.commit()
        cur.close()
        print(f"Data updated for service_id {service_id}, row {row}: {data}")

    def delete_record(self, service_id, row_id):
        """Удаляет запись из базы данных."""
        cur = self.conn.cursor()
        cur.execute("DELETE FROM all_records WHERE service_id=%s AND id=%s;", (service_id, row_id))
        self.conn.commit()
        cur.close()
        print(f"Data deleted for service_id {service_id}, row_id {row_id}")

    def load_records(self, service_id):
        """Загружает записи из базы данных и отображает их в таблице."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM all_records WHERE service_id=%s;", (service_id,))
        rows = cur.fetchall()
        self.table_widget.setRowCount(len(rows))

        for i in range(len(rows)):
            for j in range(len(rows[i])):
                item = QtWidgets.QTableWidgetItem(str(rows[i][j]))
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)
                self.table_widget.setItem(i, j, item)

        cur.close()
        print(f"Data loaded for service_id {service_id}: {rows}")

    def initUI(self):
        # Установка размеров окна
        self.setGeometry(0, 0, 1920, 1080)
        self.setWindowTitle('Приложение')

        # Установка фона
        oImage = QtGui.QImage("dragon.jpg")  # Замените на путь к вашей картинке
        sImage = oImage.scaled(self.size(), QtCore.Qt.KeepAspectRatioByExpanding)
        palette = QtGui.QPalette()
        palette.setBrush(QtGui.QPalette.Window, QtGui.QBrush(sImage))
        self.setPalette(palette)

        # Создание полупрозрачного прямоугольника колонка
        self.overlay2 = QtWidgets.QWidget(self)
        self.overlay2.setGeometry(0, 0, 400, 1080)
        self.overlay2.setStyleSheet("background-color: rgba(150, 150, 150, 170);")

        # Создание полупрозрачного прямоугольника окна
        self.overlay3 = QtWidgets.QWidget(self)
        self.overlay3.setGeometry(500, 100, 1300, 800)
        self.overlay3.setStyleSheet(
            "background-color: rgba(150, 150, 150, 170); border-radius: 30px; padding: 10px; font-size: 20px;")

        # Создание QScrollArea для кнопок сервисов
        self.scroll_area = QtWidgets.QScrollArea(self)
        self.scroll_area.setGeometry(10, 10, 380, 980)
        self.scroll_area.setWidgetResizable(True)

        # Создание контейнера для кнопок с серым фоном
        self.button_container = QtWidgets.QWidget()
        self.button_container.setStyleSheet("background-color: rgba(200, 200, 200, 255);")

        # Серый фон
        self.service_buttons_layout = QtWidgets.QVBoxLayout(self.button_container)

        # Добавление кнопки "Все записи"
        all_records_button = QtWidgets.QPushButton('Все записи', self)
        all_records_button.setStyleSheet(
            "background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: center;"
        )
        all_records_button.clicked.connect(self.change_table)
        self.service_buttons_layout.addWidget(all_records_button)
        setattr(self, 'wind0', all_records_button)

        # Кнопка для добавления новых сервисов
        self.plus_button = QtWidgets.QPushButton('+', self)
        self.plus_button.setStyleSheet(
            """ QPushButton { background-color: #c2c2c2; color: black; border: none; border-radius: 10px; font-size: 30px; } QPushButton:hover { background-color: #fdfdfd; } """)

        # Подключаем обработчик для кнопки добавления сервиса
        self.plus_button.clicked.connect(self.add_service_button)

        # Добавляем кнопку "+" в контейнер с кнопками сервисов
        self.service_buttons_layout.addWidget(self.plus_button)

        # Устанавливаем контейнер в QScrollArea
        self.scroll_area.setWidget(self.button_container)

        # Создание нового белого окна для таблицы
        self.white_window = QtWidgets.QWidget(self)
        self.white_window.setGeometry(520, 170, 1250, 700)

        # Добавление QScrollArea для прокрутки таблицы
        scroll_area_table = QtWidgets.QScrollArea(self.white_window)
        scroll_area_table.setGeometry(0, 0, 1250, 700)
        scroll_area_table.setWidgetResizable(True)

        # Кнопка редактирования таблицы
        self.pen_button = QtWidgets.QPushButton('', self)
        self.pen_button.setGeometry(1700, 110, 50, 50)

        # Устанавливаем стиль и иконку для кнопки редактирования
        icon = QtGui.QIcon('pen.png')
        self.pen_button.setIcon(icon)
        self.pen_button.setIconSize(QtCore.QSize(60, 30))

        # Подключаем обработчик нажатия на кнопку редактирования
        self.pen_button.clicked.connect(self.toggle_editing)

        # Кнопка генерации пароля
        self.password_button = QtWidgets.QPushButton('', self)
        self.password_button.setGeometry(1640, 110, 50, 50)

        # Устанавливаем стиль и иконку для кнопки
        icon = QtGui.QIcon('key.png')
        self.password_button.setIcon(icon)
        self.password_button.setIconSize(QtCore.QSize(60, 30))

        # Подключаем обработчик нажатия на кнопку
        self.password_button.clicked.connect(self.open_password_window)

        # Кнопка сохранения данных
        self.save_button = QtWidgets.QPushButton('', self)
        self.save_button.setGeometry(1580, 110, 50, 50)

        # Устанавливаем стиль и иконку для кнопки
        icon = QtGui.QIcon('save.png')
        self.save_button.setIcon(icon)
        self.save_button.setIconSize(QtCore.QSize(60, 30))

        # Подключаем обработчик нажатия на кнопку
        self.save_button.clicked.connect(self.save_table_data)

        # Добавление неинтерактивной таблицы в QScrollArea
        self.table_widget = QtWidgets.QTableWidget()

        scroll_area_table.setWidget(self.table_widget)

        headers_all = ["Идентификатор", "Название", "Логин", "Пароль", "Почта", "Дата добавления"]

        # Устанавливаем заголовки по умолчанию (все записи)
        self.table_widget.setHorizontalHeaderLabels(headers_all)

        # Настройка ширины столбцов по умолчанию
        for i in range(len(headers_all)):
            if headers_all[i] == "Дата добавления":
                self.table_widget.setColumnWidth(i, 200)
            else:
                self.table_widget.setColumnWidth(i, 100)

        # Убираем нумерацию строк и делаем таблицу неинтерактивной по умолчанию
        self.table_widget.verticalHeader().setVisible(False)
        self.table_widget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)

    def toggle_editing(self):
        """Переключает режим редактирования таблицы."""
        if self.table_widget.editTriggers() == QtWidgets.QAbstractItemView.NoEditTriggers:
            self.table_widget.setEditTriggers(
                QtWidgets.QAbstractItemView.DoubleClicked | QtWidgets.QAbstractItemView.SelectedClicked)
            self.pen_button.setStyleSheet("background-color: gray;")
        else:
            self.table_widget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
            self.pen_button.setStyleSheet("")
            self.save_table_data()

    def save_table_data(self):
        """Сохраняет данные таблицы в базу данных."""
        sender = self.sender()
        service_id = self.get_service_id(sender)
        service_name = self.get_service_name(service_id)

        if service_id is not None and service_name is not None:
            data_to_save = []
            for row in range(self.table_widget.rowCount()):
                # Собираем данные из каждой строки таблицы
                data = {
                    'name': service_name,
                    'login': self.table_widget.item(row, 1).text() if self.table_widget.item(row,
                                                                                             1) else 'default_login',
                    'password': self.table_widget.item(row, 2).text() if self.table_widget.item(row,
                                                                                                2) else 'default_password',
                    'email': self.table_widget.item(row, 3).text() if self.table_widget.item(row,
                                                                                             3) else 'default_email@example.com',
                    'date_added': self.table_widget.item(row, 4).text() if self.table_widget.item(row,
                                                                                                  4) else '2000-01-01'
                }
                # Сохраняем данные
                print(f"Saving data: {data}")  # Debugging statement
                self.save_data(service_id, data)
                data_to_save.append(data)

            # Выводим собранные данные в консоль
            for i, row_data in enumerate(data_to_save):
                print(f"Строка {i + 1}: {row_data}")

    def validate_data(self, data):
        """Проверяет корректность данных перед сохранением."""
        # Пример проверки: email должен содержать '@', а дата должна быть в правильном формате
        if '@' not in data['email']:
            return False
        try:
            # Проверка формата даты (если необходимо)
            datetime.strptime(data['date_added'], '%Y-%m-%d')
        except ValueError:
            return False
        return True

    def get_service_id(self, button):
        """Получает ID сервиса по кнопке."""
        cur = self.conn.cursor()
        cur.execute("SELECT id FROM services WHERE service_name=%s;", (button.text(),))
        result = cur.fetchone()
        cur.close()
        return result[0] if result else None

    def get_service_name(self, service_id):
        """Получает название сервиса по его ID."""
        cur = self.conn.cursor()
        cur.execute("SELECT service_name FROM services WHERE id=%s;", (service_id,))
        result = cur.fetchone()
        cur.close()
        return result[0] if result else None

    def add_service_button(self):
        """Добавляет новую кнопку сервиса."""
        new_service_button = QtWidgets.QPushButton('Новый сервис', self)
        new_service_button.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px;")

        new_service_button.mouseDoubleClickEvent = lambda event: self.rename_service(new_service_button)

        layout = self.service_buttons_layout
        layout.insertWidget(layout.count() - 1, new_service_button)

        new_service_button.clicked.connect(lambda: self.show_service_table(new_service_button))

        # Создаем таблицу для нового сервиса в базе данных
        self.create_service_table(new_service_button.text())

        # Получаем ID нового сервиса
        service_id = self.get_service_id(new_service_button)

        # Отображаем таблицу для нового сервиса с 10 пустыми строками
        self.show_service_table(new_service_button)

    def create_service_table(self, service_name):
        """Создает таблицу для нового сервиса в базе данных."""
        cur = self.conn.cursor()
        table_id = f"service_{len(self.service_buttons_layout) + 1}"
        cur.execute("""
            INSERT INTO services (service_name, table_id)
            VALUES (%s, %s)
            ON CONFLICT (service_name) DO NOTHING;
        """, (service_name, table_id))
        self.conn.commit()
        cur.close()
        print(f"Service table created for {service_name} with table_id {table_id}")

    def show_service_table(self, button):
        """Отображает таблицу соответствующего сервиса."""
        service_id = self.get_service_id(button)
        if service_id is not None:
            headers = ["Название", "Логин", "Пароль", "Почта", "Дата добавления"]
            column_count = len(headers)
            row_count = 10  # Устанавливаем количество строк в 10

            # Устанавливаем количество столбцов и строк в зависимости от выбранных заголовков.
            self.table_widget.setColumnCount(column_count)
            self.table_widget.setRowCount(row_count)

            # Устанавливаем заголовки.
            self.table_widget.setHorizontalHeaderLabels(headers)

            for i in range(column_count):
                if headers[i] == "Дата добавления":
                    self.table_widget.setColumnWidth(i, 200)
                else:
                    self.table_widget.setColumnWidth(i, 100)

            # Загружаем данные для текущего сервиса
            self.load_records(service_id)

            # Добавляем пустые строки, если записей меньше 10
            for row in range(self.table_widget.rowCount(), row_count):
                self.table_widget.insertRow(row)
                for col in range(column_count):
                    item = QtWidgets.QTableWidgetItem('')
                    self.table_widget.setItem(row, col, item)

    def rename_service(self, button):
        """Позволяет изменить название кнопки при двойном клике."""
        text_ok = button.text()
        new_text_ok, ok = QtWidgets.QInputDialog.getText(self, "Изменить название", "Введите новое название:",
                                                         text=text_ok)
        if ok and new_text_ok != '':
            button.setText(new_text_ok)
            # Обновляем название сервиса в базе данных
            cur = self.conn.cursor()
            cur.execute("UPDATE services SET service_name=%s WHERE service_name=%s;", (new_text_ok, text_ok))
            self.conn.commit()
            cur.close()
            print(f"Service renamed from {text_ok} to {new_text_ok}")

    def open_password_window(self):
        """Открывает окно генерации пароля."""
        self.password_window = PasswordWindow()
        self.password_window.show()
        print("Password generation window opened")

    def change_table(self):
        sender = self.sender()

        if sender == getattr(self, 'wind0', None):
            headers = ["Идентификатор", "Название", "Логин", "Пароль", "Почта", "Дата добавления"]
            column_count = len(headers)
            row_count = min(10, len(headers))

            # Устанавливаем количество столбцов и строк в зависимости от выбранных заголовков.
            self.table_widget.setColumnCount(column_count)
            self.table_widget.setRowCount(row_count)

            # Устанавливаем заголовки в зависимости от нажатой кнопки.
            self.table_widget.setHorizontalHeaderLabels(headers)

            for i in range(column_count):
                if headers[i] == "Дата добавления":
                    self.table_widget.setColumnWidth(i, 200)
                else:
                    self.table_widget.setColumnWidth(i, 100)

            # Загружаем данные для всех сервисов
            self.load_all_records()

        elif sender in [getattr(self, f'wind{i}', None) for i in range(1, 4)]:
            headers = ["Название", "Логин", "Пароль", "Почта", "Дата добавления"]
            column_count = len(headers)
            row_count = 10  # Устанавливаем количество строк в 10

            # Устанавливаем количество столбцов и строк в зависимости от выбранных заголовков.
            self.table_widget.setColumnCount(column_count)
            self.table_widget.setRowCount(row_count)

            # Устанавливаем заголовки в зависимости от нажатой кнопки.
            self.table_widget.setHorizontalHeaderLabels(headers)

            for i in range(column_count):
                if headers[i] == "Дата добавления":
                    self.table_widget.setColumnWidth(i, 200)
                else:
                    self.table_widget.setColumnWidth(i, 100)

    def load_all_records(self):
        """Загружает все записи из базы данных и отображает их в таблице."""
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM all_records;")
        rows = cur.fetchall()
        self.table_widget.setRowCount(len(rows))

        for i in range(len(rows)):
            for j in range(len(rows[i])):
                item = QtWidgets.QTableWidgetItem(str(rows[i][j]))
                item.setFlags(item.flags() & ~QtCore.Qt.ItemIsEditable)
                self.table_widget.setItem(i, j, item)

        cur.close()
        print(f"All records loaded: {rows}")

def main():
    app = QtWidgets.QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
