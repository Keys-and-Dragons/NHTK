import sys
from PyQt5 import QtWidgets, QtGui, QtCore


class LoginWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Установка размеров окна
        self.setGeometry(0, 0, 1920, 1080)
        self.setWindowTitle('Приложение')

        # Установка фона
        oImage = QtGui.QImage("dragon.jpg")  # Замените на путь к вашей картинке
        sImage = oImage.scaled(self.size(), QtCore.Qt.KeepAspectRatioByExpanding)
        palette = QtGui.QPalette()
        palette.setBrush(QtGui.QPalette.Window, QtGui.QBrush(sImage))
        self.setPalette(palette)

        # Создание полупрозрачного прямоугольника колонка
        self.overlay2 = QtWidgets.QWidget(self)
        self.overlay2.setGeometry(0, 0, 400, 1080)  # Размеры и позиция прямоугольника
        self.overlay2.setStyleSheet("background-color: rgba(150, 150, 150, 170);")

        # Создание полупрозрачного прямоугольника окна
        self.overlay3 = QtWidgets.QWidget(self)
        self.overlay3.setGeometry(500, 100, 1300, 800)  # Размеры и позиция прямоугольника
        self.overlay3.setStyleSheet(
            "background-color: rgba(150, 150, 150, 170); border-radius: 30px; padding: 10px; font-size: 20px;")

        # Белые поля
        self.wind1 = QtWidgets.QPushButton('Все записи', self)
        self.wind1.setGeometry(40, 20, 340, 50)
        self.wind1.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind2 = QtWidgets.QPushButton('ВК', self)
        self.wind2.setGeometry(40, 90, 340, 50)
        self.wind2.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind3 = QtWidgets.QPushButton('Telegram', self)
        self.wind3.setGeometry(40, 150, 340, 50)
        self.wind3.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind4 = QtWidgets.QPushButton('Одноклассники', self)
        self.wind4.setGeometry(40, 210, 340, 50)
        self.wind4.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        # Ползунок
        self.slider = QtWidgets.QWidget(self)
        self.slider.setGeometry(10, 10, 10, 1020)
        self.slider.setStyleSheet("background-color: #c2c2c2; border-radius: 5px; padding: 5px; font-size: 17px; ")

        self.plus_button = QtWidgets.QPushButton('+', self)
        self.plus_button.setGeometry(180, 290, 50, 50)
        self.plus_button.setStyleSheet("""
                    QPushButton {
                        background-color: #c2c2c2; 
                        color: black;              
                        border: none;              
                        border-radius: 10px;       
                        font-size: 30px;           
                    }
                    QPushButton:hover {
                        background-color: #fdfdfd; 
                    }
                """)

        self.pen_button = QtWidgets.QPushButton('', self)
        self.pen_button.setGeometry(1700, 110, 50, 50)
        self.pen_button.setStyleSheet("""
                            QPushButton {
                                background-color: #c2c2c2; 
                                color: black;              
                                border: none;              
                                border-radius: 10px;       
                                font-size: 30px;           
                            }
                            QPushButton:hover {
                                background-color: #fdfdfd; 
                            }
                        """)

        # Устанавливаем иконку
        icon = QtGui.QIcon('pen.png')
        self.pen_button.setIcon(icon)
        self.pen_button.setIconSize(QtCore.QSize(60, 30))

        # Создание нового белого окна для таблицы
        self.white_window = QtWidgets.QWidget(self)
        self.white_window.setGeometry(520, 170, 1250, 700)
        self.white_window.setStyleSheet("background-color: white; border-radius: 30px;")

        # Добавление неинтерактивной таблицы
        self.table_widget = QtWidgets.QTableWidget(self.white_window)

        # Установка количества строк и столбцов
        self.table_widget.setRowCount(17)  # Примерное количество строк
        self.table_widget.setColumnCount(5)  # Количество столбцов

        # Установка заголовков столбцов
        headers = ["Название", "Логин", "Пароль", "Почта", "Дата добавления"]
        self.table_widget.setHorizontalHeaderLabels(headers)

        # Настройка ширины столбцов
        for i in range(len(headers)):
            self.table_widget.setColumnWidth(i, 245)

            # Установка стиля для таблицы (темный фон)
        self.table_widget.setStyleSheet("""
            QTableWidget {
                background-color: rgba(240,240,240);
                border-radius: 10px;
            }
            QHeaderView::section {
                background-color: rgba(200,200,200);
                color: black;
                font-weight: bold;
            }
            QTableWidget::item {
                padding-left:5px;
            }
            QTableWidget::item:selected {
                background-color: #c2c2c2; /* Цвет выделенной строки */
            }
            """)

        # Убираем нумерацию строк и делаем таблицу неинтерактивной
        self.table_widget.verticalHeader().setVisible(False)  # Скрыть нумерацию строк
        self.table_widget.setEditTriggers(
            QtWidgets.QAbstractItemView.NoEditTriggers)  # Убрать возможность редактирования

        # Добавляем таблицу в окно
        layout = QtWidgets.QVBoxLayout(self.white_window)
        layout.addWidget(self.table_widget)


def main():
    app = QtWidgets.QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
