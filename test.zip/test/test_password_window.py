import sys
import os
import pytest
from PyQt5 import QtWidgets, QtCore
import string  # Import the string module

# Add the directory containing password_window.py to the Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from generate_password import PasswordWindow  # Now this should work

@pytest.fixture
def app(qtbot):
    test_app = QtWidgets.QApplication.instance()
    if test_app is None:
        test_app = QtWidgets.QApplication([])
    yield test_app
    test_app.quit()

@pytest.fixture
def window(qtbot):
    window = PasswordWindow()
    qtbot.addWidget(window)
    window.show()
    yield window
    window.close()

def test_initial_state(window):
    assert window.variant1_input.text() == ""
    assert window.variant2_input.text() == ""
    assert window.variant3_input.text() == ""
    assert window.use_uppercase_checkbox.text() == '✕'
    assert window.use_symbols_checkbox.text() == '✕'

def test_toggle_uppercase(window, qtbot):
    qtbot.mouseClick(window.use_uppercase_checkbox, QtCore.Qt.LeftButton)
    assert window.use_uppercase_checkbox.text() == '✓'
    qtbot.mouseClick(window.use_uppercase_checkbox, QtCore.Qt.LeftButton)
    assert window.use_uppercase_checkbox.text() == '✕'

def test_toggle_symbols(window, qtbot):
    qtbot.mouseClick(window.use_symbols_checkbox, QtCore.Qt.LeftButton)
    assert window.use_symbols_checkbox.text() == '✓'
    qtbot.mouseClick(window.use_symbols_checkbox, QtCore.Qt.LeftButton)
    assert window.use_symbols_checkbox.text() == '✕'

def test_generate_password(window, qtbot):
    window.length_input.setText('10')
    qtbot.mouseClick(window.plus_button, QtCore.Qt.LeftButton)
    assert len(window.variant1_input.text()) == 10
    assert len(window.variant2_input.text()) == 10
    assert len(window.variant3_input.text()) == 10

def test_generate_password_with_uppercase(window, qtbot):
    window.length_input.setText('10')
    qtbot.mouseClick(window.use_uppercase_checkbox, QtCore.Qt.LeftButton)
    qtbot.mouseClick(window.plus_button, QtCore.Qt.LeftButton)
    assert any(char.isupper() for char in window.variant1_input.text())
    assert any(char.isupper() for char in window.variant2_input.text())
    assert any(char.isupper() for char in window.variant3_input.text())

def test_generate_password_with_symbols(window, qtbot):
    window.length_input.setText('10')
    qtbot.mouseClick(window.use_symbols_checkbox, QtCore.Qt.LeftButton)
    qtbot.mouseClick(window.plus_button, QtCore.Qt.LeftButton)
    assert any(char in string.punctuation for char in window.variant1_input.text())
    assert any(char in string.punctuation for char in window.variant2_input.text())
    assert any(char in string.punctuation for char in window.variant3_input.text())
