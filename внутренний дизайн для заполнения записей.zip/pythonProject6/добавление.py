import sys
from PyQt5 import QtWidgets, QtGui, QtCore


class LoginWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Установка размеров окна
        self.setGeometry(0, 0, 1920, 1080)
        self.setWindowTitle('Приложение')

        # Установка фона
        oImage = QtGui.QImage("dragon.jpg")  # Замените на путь к вашей картинке
        sImage = oImage.scaled(self.size(), QtCore.Qt.KeepAspectRatioByExpanding)
        palette = QtGui.QPalette()
        palette.setBrush(QtGui.QPalette.Window, QtGui.QBrush(sImage))
        self.setPalette(palette)

        # Создание полупрозрачного прямоугольника колонка
        self.overlay2 = QtWidgets.QWidget(self)
        self.overlay2.setGeometry(0, 0, 400, 1080)  # Размеры и позиция прямоугольника
        self.overlay2.setStyleSheet("background-color: rgba(150, 150, 150, 170);")

        # Создание полупрозрачного прямоугольника окна
        self.overlay3 = QtWidgets.QWidget(self)
        self.overlay3.setGeometry(500, 100, 1300, 800)  # Размеры и позиция прямоугольника
        self.overlay3.setStyleSheet(
            "background-color: rgba(150, 150, 150, 170); border-radius: 30px; padding: 10px; font-size: 20px;")

        # Белые поля
        self.wind1 = QtWidgets.QPushButton('Все записи', self)
        self.wind1.setGeometry(40, 20, 340, 50)
        self.wind1.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind2 = QtWidgets.QPushButton('ВК', self)
        self.wind2.setGeometry(40, 90, 340, 50)
        self.wind2.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind3 = QtWidgets.QPushButton('Telegram', self)
        self.wind3.setGeometry(40, 150, 340, 50)
        self.wind3.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        self.wind4 = QtWidgets.QPushButton('Одноклассники', self)
        self.wind4.setGeometry(40, 210, 340, 50)
        self.wind4.setStyleSheet("background-color: white; border-radius: 20px; padding: 10px; font-size: 20px; text-align: left;")

        # Ползунок
        self.slider = QtWidgets.QWidget(self)
        self.slider.setGeometry(10, 10, 10, 1020)
        self.slider.setStyleSheet("background-color: #c2c2c2; border-radius: 5px; padding: 5px; font-size: 17px; ")

        self.plus_button = QtWidgets.QPushButton('+', self)
        self.plus_button.setGeometry(180, 290, 50, 50)
        self.plus_button.setStyleSheet("""
                    QPushButton {
                        background-color: #c2c2c2; 
                        color: black;              
                        border: none;              
                        border-radius: 10px;       
                        font-size: 30px;           
                    }
                    QPushButton:hover {
                        background-color: #fdfdfd; 
                    }
                """)

        # Создание нового белого окна для таблицы
        self.white_window = QtWidgets.QWidget(self)
        self.white_window.setGeometry(520, 170, 1250, 700)
        self.white_window.setStyleSheet("background-color: white; border-radius: 30px;")

        # Создание элементов интерфейса
        self.username_label = QtWidgets.QLabel('Введите логин:', self)
        self.username_label.move(560, 200)
        self.username_label.setStyleSheet("font-size: 20px;")

        self.username_input = QtWidgets.QLineEdit(self)
        self.username_input.setGeometry(565, 230, 400, 50)
        self.username_input.setStyleSheet("border-radius: 20px; padding: 10px; font-size: 17px; background-color: #c2c2c2;")

        self.password_label = QtWidgets.QLabel('Введите пароль:', self)
        self.password_label.move(560, 300)
        self.password_label.setStyleSheet("font-size: 20px;")

        # Создаем поле ввода для пароля
        self.password_input = QtWidgets.QLineEdit(self)
        self.password_input.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_input.setGeometry(565, 330, 400, 50)
        self.password_input.setStyleSheet("border-radius: 20px; padding: 10px; font-size: 17px; background-color: #c2c2c2;")

        self.mail_label = QtWidgets.QLabel('Введите почту:', self)
        self.mail_label.move(560, 400)
        self.mail_label.setStyleSheet("font-size: 20px;")

        self.mail_input = QtWidgets.QLineEdit(self)
        self.mail_input.setGeometry(565, 430, 400, 50)
        self.mail_input.setStyleSheet(
            "border-radius: 20px; padding: 10px; font-size: 17px; background-color: #c2c2c2;")

        self.overlay2 = QtWidgets.QWidget(self)
        self.overlay2.setGeometry(550, 520, 1190, 200)  # Размеры и позиция прямоугольника
        self.overlay2.setStyleSheet("background-color: #c2c2c2;")

        self.plus_button = QtWidgets.QPushButton('Сгенерировать пароль', self)
        self.plus_button.setGeometry(550, 740, 1190, 50)
        self.plus_button.setStyleSheet("""
                            QPushButton {
                                background-color: #c2c2c2; 
                                color: black;              
                                border: none;              
                                border-radius: 10px;       
                                font-size: 20px;           
                            }
                        """)

        self.plus_button = QtWidgets.QPushButton('Добавить запись', self)
        self.plus_button.setGeometry(550, 800, 1190, 50)
        self.plus_button.setStyleSheet("""
                                    QPushButton {
                                        background-color: #c2c2c2; 
                                        color: black;              
                                        border: none;              
                                        border-radius: 10px;       
                                        font-size: 20px;           
                                    }
                                """)

        # Создание окон условий
        self.wind1 = QtWidgets.QPushButton('Использовать знаки препинания', self)
        self.wind1.setGeometry(600, 550, 340, 50)
        self.wind1.setStyleSheet(
            "background-color: white; padding: 10px; font-size: 20px; text-align: left;")

        self.wind1 = QtWidgets.QPushButton('Использовать заглавные буквы', self)
        self.wind1.setGeometry(1180, 550, 340, 50)
        self.wind1.setStyleSheet(
            "background-color: white; padding: 10px; font-size: 20px; text-align: left;")

        self.wind1 = QtWidgets.QPushButton('Количество символов', self)
        self.wind1.setGeometry(600, 630, 340, 50)
        self.wind1.setStyleSheet(
            "background-color: white; padding: 10px; font-size: 20px; text-align: left;")

        # Создание кнопок условий
        self.pen_button = QtWidgets.QPushButton('✓', self)
        self.pen_button.setGeometry(970, 548, 50, 50)
        self.pen_button.setStyleSheet("""
                                    QPushButton {
                                        background-color: #fdfdfd; 
                                        color: black;              
                                        border: none;              
                                        border-radius: 10px;       
                                        font-size: 30px;           
                                    }
                                """)

        self.pen_button = QtWidgets.QPushButton('✕', self)
        self.pen_button.setGeometry(1550, 548, 50, 50)
        self.pen_button.setStyleSheet("""
                                            QPushButton {
                                                background-color: #fdfdfd; 
                                                color: black;              
                                                border: none;              
                                                border-radius: 10px;       
                                                font-size: 30px;           
                                            }
                                        """)

        self.num_input = QtWidgets.QLineEdit(self)
        self.num_input.setGeometry(970, 628, 50, 50)
        self.num_input.setStyleSheet(
            "border-radius: 10px; padding: 10px; font-size: 19px; background-color: #fdfdfd;")


def main():
    app = QtWidgets.QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
