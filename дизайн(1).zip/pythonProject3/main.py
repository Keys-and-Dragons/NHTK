import sys
from PyQt5 import QtWidgets, QtGui, QtCore

class LoginWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # Установка размеров окна
        self.setGeometry(0, 0, 1350, 1000)
        self.setWindowTitle('Авторизация')

        # Установка фона
        oImage = QtGui.QImage("cartoon-castle-11310807.jpg")  # Замените на путь к вашей картинке
        sImage = oImage.scaled(self.size(), QtCore.Qt.KeepAspectRatioByExpanding)
        palette = QtGui.QPalette()
        palette.setBrush(QtGui.QPalette.Window, QtGui.QBrush(sImage))
        self.setPalette(palette)

        # Создание полупрозрачного прямоугольника
        self.overlay = QtWidgets.QWidget(self)
        self.overlay.setGeometry(340, 230, 650, 350)  # Размеры и позиция прямоугольника
        self.overlay.setStyleSheet("background-color: rgba(150, 150, 150, 230);")

        # Создаем QLabel для отображения изображения
        self.lbl = QtWidgets.QLabel(self)
        self.pix = QtGui.QPixmap("PicsArt_12-11-04.58.56.png")
        self.pix = self.pix.scaled(400, 300, QtCore.Qt.KeepAspectRatio)
        self.lbl.setPixmap(self.pix)
        self.lbl.resize(self.pix.width(), self.pix.height())
        self.lbl.move(470, 650)

        # Создание элементов интерфейса
        self.username_label = QtWidgets.QLabel('Введите логин:', self)
        self.username_label.move(460, 270)
        self.username_label.setStyleSheet("font-size: 20px;")

        self.username_input = QtWidgets.QLineEdit(self)
        self.username_input.setGeometry(465, 300, 400, 50)
        self.username_input.setStyleSheet("border-radius: 20px; padding: 10px; font-size: 17px;")  # Скругленные края

        self.password_label = QtWidgets.QLabel('Введите пароль:', self)
        self.password_label.move(460, 370)
        self.password_label.setStyleSheet("font-size: 20px;")

        self.password_input = QtWidgets.QLineEdit(self)
        self.password_input.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_input.setGeometry(465, 400, 400, 50)
        self.password_input.setStyleSheet("border-radius: 20px; padding: 10px; font-size: 17px;")

        self.login_button = QtWidgets.QPushButton('Войти', self)
        self.login_button.setGeometry(720, 500, 200, 35)
        self.login_button.setStyleSheet("""
                    QPushButton {
                        background-color: #c2c2c2; 
                        color: black;              
                        border: none;              
                        border-radius: 15px;       
                        font-size: 15px;           
                    }
                    QPushButton:hover {
                        background-color: #fdfdfd; 
                    }
                """)

        self.create_button = QtWidgets.QPushButton('Создать аккаунт', self)
        self.create_button.setGeometry(420, 500, 200, 35)
        self.create_button.setStyleSheet("""
                    QPushButton {
                        background-color: #c2c2c2; 
                        color: black;              
                        border: none;              
                        border-radius: 15px;       
                        font-size: 15px;           
                    }
                    QPushButton:hover {
                        background-color: #fdfdfd; 
                    }
                """)
        self.create_button.clicked.connect(self.handle_login)


    def handle_login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        print(f'Логин: {username}, Пароль: {password}')  # Здесь можно добавить логику для проверки логина

def main():
    app = QtWidgets.QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
